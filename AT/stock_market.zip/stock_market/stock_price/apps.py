from django.apps import AppConfig


class StockPriceConfig(AppConfig):
    name = 'stock_price'
