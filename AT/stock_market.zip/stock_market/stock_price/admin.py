from django.contrib import admin
from .models import Company


admin.site.register(Company)
#Registering the model. So that I can use it.  
